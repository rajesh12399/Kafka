package com.aoerp.aoerpsalesorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AoerpsalesorderserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
