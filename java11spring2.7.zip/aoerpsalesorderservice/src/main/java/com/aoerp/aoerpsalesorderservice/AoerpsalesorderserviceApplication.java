package com.aoerp.aoerpsalesorderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AoerpsalesorderserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AoerpsalesorderserviceApplication.class, args);
	}

}
